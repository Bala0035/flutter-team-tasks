

class Dummymodul {
  String data;

  Dummymodul({required this.data});
}
