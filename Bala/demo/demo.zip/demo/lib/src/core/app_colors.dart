

import 'package:flutter/material.dart';

class AppColors {
  const AppColors._();

   static const themecolor = Colors.green;

}