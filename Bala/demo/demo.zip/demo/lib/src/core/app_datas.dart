

class AppData {
  const AppData._();

   static const appName = 'AppName';

}