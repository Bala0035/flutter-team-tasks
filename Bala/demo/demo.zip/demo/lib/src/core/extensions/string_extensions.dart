

extension SuperString on String{
//* DUMMY
}

class StringExtension  {
 
  const StringExtension._();
  //* DUMMY
}

String capitalize(String s) => s[0].toUpperCase() + s.substring(1);