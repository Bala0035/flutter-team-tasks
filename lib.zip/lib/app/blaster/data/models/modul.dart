

class Dummymodul {
  String data;

  Dummymodul({required this.data});
}

class Inventory{
Inventory({required this.descriptionofitem,
required this.unit,required this.crntqty});
  // ignore: prefer_typing_uninitialized_variables
  var descriptionofitem;
  var unit;
  var crntqty;
}
