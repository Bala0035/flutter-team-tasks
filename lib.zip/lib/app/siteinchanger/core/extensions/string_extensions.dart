

extension SuperString on String{
//* DUMMY
}


String capitalize(String s) => s[0].toUpperCase() + s.substring(1);