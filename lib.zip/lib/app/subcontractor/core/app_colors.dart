import 'package:flutter/material.dart';


class AppColor {
  const AppColor._();

  static const themeColor = Color.fromARGB(255, 3, 8, 87);
  
 static const inputbgclr = Color.fromARGB(255, 211, 206, 206);

}
