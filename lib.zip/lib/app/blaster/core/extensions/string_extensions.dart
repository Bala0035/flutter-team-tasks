

extension SuperString on String{
//* DUMMY
}

class StringExtension  {
 
   StringExtension._();
static const appName = 'Inventory';

// APIs
static const loginApi = "http://129.154.47.8:8083/api/user/all";
static const stockApi = "http://129.154.47.8:8083/api/stock/all";

// String stockApi="https://raw.githubusercontent.com/Bala0035/demoAPIs/main/stockapi.json";

static const blastingRequestHeaderAPi =
    "http://129.154.47.8:8083/api/blastingRequestHeader/all";

static const blastingRequestApi = "http://129.154.47.8:8083/api/blastingRequest/all";

static const dscbitemApi =
    "https://raw.githubusercontent.com/Bala0035/demoAPIs/main/idem.json";
//TEXT formates

  //* DUMMY
}

String capitalize(String s) => s[0].toUpperCase() + s.substring(1);
String dateget(String s) => s.split("T")[0];
String shiftget(String s) =>  s[0].toUpperCase();
String balsterGetByID(String s) =>  s[0].toUpperCase();