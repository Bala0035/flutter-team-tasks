
import '/src/data/models/modul.dart';

List<Dummymodul> dummyDeta=[
  Dummymodul(data:"bala")
];