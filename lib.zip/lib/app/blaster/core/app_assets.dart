class AppAssets {
  const AppAssets._();

  //* DUMMY
  //  static const applogo = "assets/img/logo.png";

}